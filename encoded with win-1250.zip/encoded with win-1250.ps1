# This file is encoded with "Central European" Windows 1250:
Write-Host "(Naci�nij dowolny klawisz, aby zako�czy�)" -NoNewline
[void][System.Console]::ReadKey($true)