# This file is encoded with "Central European" Windows 1250:
Write-Host "Za��ci�o g�si� ja��"
Write-Host "(Naci�nij dowolny klawisz, aby zako�czy�)" -NoNewline
[void][System.Console]::ReadKey($true)